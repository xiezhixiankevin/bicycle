package cn.itcast.feign.common;

/**
 * <Description> ResultCode
 *
 * @author 26802
 * @version 1.0
 */
public interface ResultCode {
    public static Integer SUCCESS = 20000;
    public static Integer ERROR = 20001;
}